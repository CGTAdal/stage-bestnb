<!--<link href="includes/cms.css" rel="stylesheet" type="text/css" />-->
<link rel="stylesheet" href="css/screen.css" type="text/css" media="screen" title="no title" charset="utf-8" />	
<link rel="stylesheet" href="css/plugin.css" type="text/css" media="screen" title="no title" charset="utf-8" />	
<link rel="stylesheet" href="css/custom.css" type="text/css" media="screen" title="no title" charset="utf-8" />
<script  type="text/javascript" src="<?php echo $base_url;?>/admin/scripts/jquery-1.3.2.min.js"></script>