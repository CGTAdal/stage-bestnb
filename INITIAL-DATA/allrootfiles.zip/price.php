<?php include('inc/prices.php'); ?>

<table width="565" border="0" align="center" cellpadding="2" cellspacing="3" style="font-size: 11px;">
        <tr>
          <td width="123" align="center" bgcolor="#738539"><strong style="color: #FFF">Badge Quantity</strong></td>
          <td width="80" align="center" bgcolor="#738539"><strong style="color: #FFF">Price</strong></td>
          <td width="99" align="center" bgcolor="#738539"><strong style="color: #FFF">Colors</strong></td>
          <td width="148" align="center" bgcolor="#738539"><strong style="color: #FFF">Fastener<br />
          </strong></td>
          <td width="105" align="center" bgcolor="#738539"><strong style="color: #FFF">Shipping</strong></td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">1 - 10</td>
          <td align="center" bgcolor="#ececec"><span style="text-decoration:line-through;">$<?php echo $pricepro1sale ; ?>/ea</span><br />
            <span style="color:#F00;">$<?php echo $pricepro1 ; ?>/ea</span></td>
          <td align="center" bgcolor="#ececec">Full Color</td>
          <td align="center" bgcolor="#ececec">Magnet or Pin Included</td>
          <td align="center" bgcolor="#ececec">Free</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">11-25</td>
          <td align="center" bgcolor="#ececec"><span style="text-decoration:line-through;">$<?php echo $pricepro2sale ; ?>/ea</span><br />
            <span style="color:#F00;">$<?php echo $pricepro2 ; ?>/ea</span></td>
          <td align="center" bgcolor="#ececec">Full Color</td>
          <td align="center" bgcolor="#ececec">Magnet or Pin Included</td>
          <td align="center" bgcolor="#ececec">Free</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">26-50</td>
          <td align="center" bgcolor="#ececec"><span style="text-decoration:line-through;">$<?php echo $pricepro3sale ; ?>/ea</span><br />
            <span style="color:#F00;">$<?php echo $pricepro3 ;?>/ea</span></td>
          <td align="center" bgcolor="#ececec">Full Color</td>
          <td align="center" bgcolor="#ececec">Magnet or Pin Included</td>
          <td align="center" bgcolor="#ececec">Free</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">51-100</td>
          <td align="center" bgcolor="#ececec"><span style="text-decoration:line-through;">$<?php echo $pricepro4sale ; ?>/ea</span><br />
            <span style="color:#F00;">$<?php echo $pricepro4 ;?>/ea</span></td>
          <td align="center" bgcolor="#ececec">Full Color</td>
          <td align="center" bgcolor="#ececec">Magnet or Pin Included</td>
          <td align="center" bgcolor="#ececec">Free</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">101-250</td>
          <td align="center" bgcolor="#ececec"><span style="text-decoration:line-through;">$<?php echo $pricepro5sale ; ?>/ea</span><br />
            <span style="color:#F00;">$<?php echo $pricepro5 ;?>/ea</span></td>
          <td align="center" bgcolor="#ececec">Full Color</td>
          <td align="center" bgcolor="#ececec">Magnet or Pin Included</td>
          <td align="center" bgcolor="#ececec">Free</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">251-1000</td>
          <td align="center" bgcolor="#ececec"><span style="text-decoration:line-through;">$<?php echo $pricepro6sale ; ?>/ea</span><br />
            <span style="color:#F00;">$<?php echo $pricepro6 ;?>/ea</span></td>
          <td align="center" bgcolor="#ececec">Full Color</td>
          <td align="center" bgcolor="#ececec">Magnet or Pin Included</td>
          <td align="center" bgcolor="#ececec">Free</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">1001 - 10000</td>
          <td align="center" bgcolor="#ececec"><span style="text-decoration:line-through;">$<?php echo $pricepro7sale ; ?>/ea</span><br />
            <span style="color:#F00;">$<?php echo $pricepro7 ;?>/ea</span></td>
		  <td align="center" bgcolor="#ececec">Full Color</td>
          <td align="center" bgcolor="#ececec">Magnet or Pin Included</td>
          <td align="center" bgcolor="#ececec">Free</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#738539"><strong style="color:#FFF;">Badge Frames</strong></td>
          <td align="center" bgcolor="#738539"><strong style="color:#FFF;">Price</strong></td>
          <td align="center">&nbsp;</td>
          <td align="center">&nbsp;</td>
          <td align="center">&nbsp;</td>
        </tr>
        <tr>
          <td align="center" bgcolor="#ececec">All Sizes/Colors</td>
          <td align="center" bgcolor="#ececec">$<?php echo $priceframes ;?>/ea</td>
          <td align="center" bgcolor="#ececec">&nbsp;</td>
          <td align="center" bgcolor="#ececec">&nbsp;</td>
          <td align="center" bgcolor="#ececec">&nbsp;</td>
        </tr>
    
                  <tr>
                   <td align="center" bgcolor="#738539"><strong style="color:#FFF;">Badge Domes</strong></td>
                   <td align="center" bgcolor="#738539"><strong style="color:#FFF;">Price</strong></td>
                   <td align="center">&nbsp;</td>
                   <td align="center">&nbsp;</td>
                   <td align="center">&nbsp;</td>
              </tr>
                 <tr>
                   <td align="center" bgcolor="#ececec">Polyurethane Domed Lens</td>
                   <td align="center" bgcolor="#ececec">$2.75/ea</td>
                   <td align="center" bgcolor="#ececec">&nbsp;</td>
                   <td align="center" bgcolor="#ececec">&nbsp;</td>
                   <td align="center" bgcolor="#ececec">&nbsp;</td>
                 </tr>
      </table>