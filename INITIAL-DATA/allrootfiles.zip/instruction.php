 <h2 style="float: left; clear: both; margin-bottom: 35px;">Large Quantity Ordering</h2>
       <br />
<div style="width: 840px; float: left; padding: 15px 20px 15px 15px; border-top: solid 1px #c1c1c1; border-bottom: solid 1px #c1c1c1; margin-bottom: 15px;">
      <strong style="font-size: 18px;">Instructions</strong>
      <p>      Are you ordering a high quantity of badges and don't wish to add each individually?  Place your total in "Prepay For Extra Badges&quot; - once you complete checkout, send us your names list or instructions via email at <a href="mailto:support@bestnamebadges.com">support@bestnamebadges.com</a>
    </p>
      <p>If you have any questions at all, just give us a call at 888-445-7601</p>
      
    </div>