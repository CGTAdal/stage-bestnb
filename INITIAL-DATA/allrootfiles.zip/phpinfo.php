<?php 
 echo phpinfo();
?>