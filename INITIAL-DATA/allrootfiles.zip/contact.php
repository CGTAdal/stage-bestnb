<?php 
$pagetitle = "Contact Best Name Badges";
$metadescription = "Getting in touch with us is easy.  Call us anytime or write an email.  We'll be there for you.";
$metakeywords = "";
session_start();

if ($_SESSION["customerloginid"])

{

	include_once 'inc/header-auth.php';

} else {

	include_once 'inc/header.php' ;

} ?>


  <div id="content">
   
    <div id="home-main">
    
      <div id="home-right" class="corners">
        <div class="content-sub">
       	  <div class="content-sub-2">
          <h2><br />
           Contact Best Name Badges</h2>
               <h4>We would love to hear from you.<br /><br />
                 
                 <br />
                 <br />
<br />
</h4>

<h3>Call Us Right Now: <strong>(888) 445-7601</strong></h3>
<br /><br />
            <p>Contact us with confidence, we'll be right with you.<br />
If you would like a call back, please specify in your message</p>
            
    <br />
            

            <h3>General Email Contacts:</h3>
<p>Support -  <script type="text/javascript">
/*<![CDATA[*/
var emailriddlerarray=[115,117,112,112,111,114,116,64,98,101,115,116,110,97,109,101,98,97,100,103,101,115,46,99,111,109]
var encryptedemail_id94=''
for (var i=0; i<emailriddlerarray.length; i++)
 encryptedemail_id94+=String.fromCharCode(emailriddlerarray[i])

document.write('<a href="mailto:'+encryptedemail_id94+'">'+encryptedemail_id94+'</a>')

/*]]>*/
</script><br />
  Sales - <script type="text/javascript">
/*<![CDATA[*/

var emailriddlerarray=[115,97,108,101,115,64,98,101,115,116,110,97,109,101,98,97,100,103,101,115,46,99,111,109]
var encryptedemail_id53='' 
for (var i=0; i<emailriddlerarray.length; i++)
 encryptedemail_id53+=String.fromCharCode(emailriddlerarray[i])

document.write('<a href="mailto:'+encryptedemail_id53+'">'+encryptedemail_id53+'</a>')

/*]]>*/
</script><br />
</p>
<h3><br />
  Operations Manager</h3>
<p>Alex Edwards - 
  <script type="text/javascript">
/*<![CDATA[*/


var emailriddlerarray=[97,108,101,120,64,98,101,115,116,110,97,109,101,98,97,100,103,101,115,46,99,111,109]
var encryptedemail_id87=''  
for (var i=0; i<emailriddlerarray.length; i++)
 encryptedemail_id87+=String.fromCharCode(emailriddlerarray[i])

document.write('<a href="mailto:'+encryptedemail_id87+'">'+encryptedemail_id87+'</a>')

/*]]>*/
</script></p><br />
<br />

          </div>
        </div>
      </div>
      
      <div id="home-left" class="corners">
      <div class="content-sub">
        <div class="content-sub-2">
      	
      <div style="float: left;">
        <img src="/images/free-shipping.jpg" alt="Free Shipping on Name Badges and Tags" width="83" height="83" style="float: left;" />
        <p style="float: right; padding-left: 15px; margin-top: 0px; width: 120px;">
        Don't pay a penny for shipping.<br />
        <br />
        No minimum necessary. </p>
        </div>
        </div>
        </div>
      </div>
      
      
       <div id="home-left2" class="corners">
      <div class="content-sub">
        <div class="content-sub-2">
          <h3>Some Clients We Serve:<br />
        <br />

      </h3>
      <p style="margin-left: 10px; text-align: center;"><img src="images/partners/carmax.jpg" width="182" height="49" alt="Plastic Name Tags" /><br />
<br />
<img src="images/partners/belair.jpg" width="151" height="112" alt="Custom Name Badges" /><br />
<br />
<img src="images/partners/westin.jpg" width="180" height="62" alt="Custom Magnetic Name Badges" /><br />
<br />
<img src="images/partners/sensations.jpg" width="180" height="74" alt="Employee Name Badges" /></p>
        </div>
        </div>
      </div>
      
      
    </div>
    
  </div>
  
  <?php include_once '_footer.php' ?>